import express from "express";
import multer from "multer";
import path from "path";
import JobController from "../controller/job.controller";
import { requireSignIn } from "../middleware/auth.middleware";
import { validateMiddleware } from "../middleware/validator.middleware";
import { jobApplicantValidation, jobUpdateValidation, jobValidation } from "../validator/job.validator";
const router = express.Router()

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        if (file.fieldname == "jobImage") {
            cb(null, './public/images/jobImage/');
        }
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    },
});

const upload = multer({
    storage: storage, limits: { fileSize: 1000000 }

});

const jobController = new JobController();

// Route to create a new job
router.post("/create-job", requireSignIn, upload.single('jobImage'), validateMiddleware(jobValidation), jobController.createJob);

// Route to update event
router.put("/update-job", requireSignIn, upload.single('jobImage'), validateMiddleware(jobUpdateValidation), jobController.updateJob);

// Route to delete job
router.delete("/delete-job/:jobid", requireSignIn, jobController.deleteJob);

// Route to get job 
router.get("/get", jobController.getAllJob);

// Route to apply job 
router.post("/applyJob",requireSignIn,validateMiddleware(jobApplicantValidation), jobController.applyJob);

export default router;

